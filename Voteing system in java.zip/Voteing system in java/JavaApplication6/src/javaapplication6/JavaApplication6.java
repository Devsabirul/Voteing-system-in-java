package javaapplication6;
import javax.swing.*;

public class JavaApplication6 {
    public static void main(String[] args) {
        // TODO code application logic here
        JOptionPane.showMessageDialog(null,"Invalide!","Error Message",JOptionPane.ERROR_MESSAGE);
    }
    
}
