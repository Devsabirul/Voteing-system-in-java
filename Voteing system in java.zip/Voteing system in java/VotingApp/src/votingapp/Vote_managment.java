package votingapp;

import java.util.Scanner;

public class Vote_managment {
       String num1 = "1. Rakib Hasan Ommi. ";
       String num2 = "2. Krisna sami. ";
       String num3 = "3. Khairul alam. ";
       String num4 = "4. Sajjad Hasan. ";
       String  num5 = "5. Ramia Chowdori. ";
       String con1 = "1. yes ";
       String con2 = "2. No ";
       String confirmMessage = "   Thanks for voting.";
       String message = "Your Selected Is ";
       int num;
       int confirm;
    //Get Input form Voter
    Scanner input = new Scanner(System.in);

    public void userInput() {
        System.out.print("Enter your NID Number: ");
        long NidNum = input.nextLong();
        
    }
    void voterlist() {
        System.out.println("* 5 Candidates are Available Right Now. *");
        System.out.println("==========");
        System.out.println(num1);
        System.out.println(num2);
        System.out.println(num3);
        System.out.println(num4);
        System.out.println(num5);
    }
    void confirm(){
                System.out.println(con1);
                System.out.println(con2);
                //select yes or no 
                System.out.print("Choose: ");
                confirm = input.nextInt();
                switch(confirm){
                    case 1:
                        System.out.println(confirmMessage);
                        break;
                    case 2:
                        System.out.println(confirmMessage);
                        break;
                        default:
                        System.out.println("Invalid Number to confirm!!!");
                }
    }
    void getvote(){
         //Get vote 
        System.out.print("Select Your Candidate : ");
        num = input.nextInt();
        switch (num) {
            case 1:
                System.out.println(message +  num1);
                //for confirm your vote
                confirm();
                break;
                case 2:
                System.out.println(message +  num2);
                //for confirm your vote
                confirm();
                break;
                case 3:
                System.out.println(message +  num3);
                //for confirm your vote
                confirm();
                break;
                case 4:
                System.out.println(message +  num4);
                //for confirm your vote
                confirm();
                break;
                case 5:
                System.out.println(message +  num5);
                //for confirm your vote
                confirm();
                break;
                default:
                    System.out.println("======");
                    System.out.println("Candidates are not Available!!!");
                    
        }
    }
}
