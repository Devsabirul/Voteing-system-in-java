package votingapp;

public class VotingApp {

    public static void main(String[] args) {
        //create object!
        Vote_managment vote = new Vote_managment();
        System.out.println("Welcome to our Vote Management app!");
        System.out.println("==========");
        vote.userInput();
        System.out.println("=============");
        vote.voterlist();
        System.out.println("===========");
        vote.getvote();
    }

}
